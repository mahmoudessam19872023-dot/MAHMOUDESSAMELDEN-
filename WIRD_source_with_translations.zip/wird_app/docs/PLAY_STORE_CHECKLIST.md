# Google Play release checklist — WIRD

- [ ] Confirm final Arabic/English app name and unique package ID.
- [ ] Generate Android platform files with Flutter stable.
- [ ] Add original 512×512 Play icon and feature graphic (1024×500).
- [ ] Validate Quran text and page boundaries against a trusted Mushaf edition.
- [ ] Confirm rights/terms for each reciter recording and content API/CDN.
- [ ] Test audio focus, interruptions, background playback, locked screen, headphones, Bluetooth, and network loss.
- [ ] Test on Android 8–latest supported Android; check RTL and large font scaling.
- [ ] Implement privacy policy and accurately complete Data safety.
- [ ] Complete store listing, screenshots, category, contact details, content rating.
- [ ] Configure signing key, build release AAB, test internal track, then submit for review.
