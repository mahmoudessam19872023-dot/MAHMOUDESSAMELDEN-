import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:audio_service/audio_service.dart';
import 'quran_audio_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

const emerald = Color(0xFF0D493D);
const gold = Color(0xFFC6A66A);
const paper = Color(0xFFF7F3E9);
const api = 'https://api.alquran.cloud/v1';

late final QuranAudioHandler audioHandler;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  audioHandler = await AudioService.init(
    builder: () => QuranAudioHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.wird.quran.playback',
      androidNotificationChannelName: 'وِرد - تلاوة القرآن',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: false,
      androidNotificationIcon: 'drawable/ic_stat_wird',
      notificationColor: emerald,
    ),
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: paper, systemNavigationBarIconBrightness: Brightness.dark));
  runApp(const WirdApp());
}

class WirdApp extends StatelessWidget {
  const WirdApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'وِرد | WIRD', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: paper,
      colorScheme: ColorScheme.fromSeed(seedColor: emerald, surface: paper),
      textTheme: GoogleFonts.cairoTextTheme(), appBarTheme: const AppBarTheme(backgroundColor: emerald, foregroundColor: Colors.white, elevation: 0)),
    home: const HomeScreen());
}

class QuranApi {
  static Future<Map<String,dynamic>> page(int n) async {
    final r = await http.get(Uri.parse('$api/page/$n/quran-uthmani')).timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('تعذر تحميل الصفحة');
    return jsonDecode(r.body)['data'];
  }
  static Future<List<dynamic>> pageTranslation(int n, String edition) async {
    final r=await http.get(Uri.parse('$api/page/$n/$edition')).timeout(const Duration(seconds:20));
    if(r.statusCode!=200) throw Exception('تعذر تحميل الترجمة');
    return (jsonDecode(r.body)['data']['ayahs'] as List);
  }
  static Future<List<dynamic>> surahs() async {
    final r = await http.get(Uri.parse('$api/surah')).timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('تعذر تحميل السور');
    return jsonDecode(r.body)['data'];
  }
  static Future<List<dynamic>> reciters() async {
    final r = await http.get(Uri.parse('$api/edition/format/audio')).timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('تعذر تحميل القراء');
    final all = jsonDecode(r.body)['data'] as List;
    const preferred = ['ar.husary','ar.minshawi','ar.abdulbasit','ar.alafasy','ar.muhammadayyoub','ar.mahermuaiqly'];
    final found = <dynamic>[];
    for (final id in preferred) { for (final e in all) { if (e['identifier']==id) found.add(e); } }
    return found.isNotEmpty ? found : all.where((e)=>e['language']=='ar' && e['type']=='versebyverse').take(12).toList();
  }
}

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int pageNo=1, tab=0; bool dark=false, loading=true, pageMode=true, playing=false;
  Map<String,dynamic>? pageData; List<dynamic> surahs=[]; List<dynamic> reciters=[];
  List<dynamic> translationAyahs=[];
  String translationEdition='en.sahih';
  String reciter='ar.husary', reciterName='محمود خليل الحصري';
  int? queuedPage; String? queuedReciter; final prefsFuture=SharedPreferences.getInstance();
  @override void initState(){super.initState(); _init(); audioHandler.playingStream.listen((v){if(mounted)setState(()=>playing=v);});}
  Future<void> _init() async { try { final p=await prefsFuture; pageNo=p.getInt('lastPage')??1; final results=await Future.wait([QuranApi.page(pageNo),QuranApi.surahs(),QuranApi.reciters(),QuranApi.pageTranslation(pageNo,translationEdition)]); if(!mounted)return; setState((){pageData=results[0] as Map<String,dynamic>;surahs=results[1] as List;reciters=results[2] as List;translationAyahs=results[3] as List;loading=false;}); } catch(e){if(mounted)setState(()=>loading=false);} }
  Future<void> loadPage(int n) async { if(n<1||n>604)return; await audioHandler.stop(); queuedPage=null; queuedReciter=null; setState(()=>loading=true); try{final results=await Future.wait([QuranApi.page(n),QuranApi.pageTranslation(n,translationEdition)]); final d=results[0] as Map<String,dynamic>; final tr=results[1] as List; final p=await prefsFuture; await p.setInt('lastPage',n); if(!mounted)return; setState((){pageData=d;translationAyahs=tr;}); }catch(_){_snack('تعذر تحميل الصفحة. تحقق من الاتصال.');} finally{if(mounted)setState(()=>loading=false);} }
  void _snack(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s,textAlign:TextAlign.center)));
  String translationFor(dynamic ayah) { final number=ayah['number']; final found=translationAyahs.where((x)=>x['number']==number).toList(); return found.isEmpty?'':(found.first['text']?.toString()??''); }
  Future<void> changeTranslation(String edition) async { setState((){translationEdition=edition;loading=true;}); try { final translated=await QuranApi.pageTranslation(pageNo,edition); if(!mounted)return; setState((){translationAyahs=translated;loading=false;}); } catch (_) { if(mounted){setState(()=>loading=false);_snack('تعذر تحميل الترجمة. تحقق من الاتصال.');} } }
  Future<void> playCurrent() async {
    final ayahs=(pageData?['ayahs'] as List? ?? []);
    if(ayahs.isEmpty)return;
    try {
      if(playing){await audioHandler.pause();return;}
      if(queuedPage==pageNo && queuedReciter==reciter){await audioHandler.play();return;}
      await audioHandler.playPage(ayahs: ayahs, reciterId: reciter, reciterName: reciterName, pageNumber: pageNo);
      queuedPage=pageNo; queuedReciter=reciter;
    }catch(e){_snack('تعذر تشغيل التلاوة حالياً.');}
  }
  @override void dispose(){super.dispose();}
  @override Widget build(BuildContext context){
    final bg=dark?const Color(0xFF14221F):paper; final fg=dark?const Color(0xFFECE5D5):const Color(0xFF26352F);
    return Scaffold(backgroundColor:bg, body:SafeArea(child: tab==1?_surahTab(bg,fg):tab==2?_settings(bg,fg):_home(bg,fg)) ,
      bottomNavigationBar:NavigationBar(backgroundColor:dark?const Color(0xFF1B302A):Colors.white,selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'المصحف'),NavigationDestination(icon:Icon(Icons.list_alt),label:'السور'),NavigationDestination(icon:Icon(Icons.tune),label:'الإعدادات')]));
  }
  Widget _home(Color bg,Color fg)=>CustomScrollView(slivers:[
    SliverToBoxAdapter(child:Container(padding:const EdgeInsets.fromLTRB(22,20,22,28),decoration:const BoxDecoration(color:emerald,borderRadius:BorderRadius.vertical(bottom:Radius.circular(28))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[const Icon(Icons.auto_awesome,color:gold),const SizedBox(width:8),Text('وِرد',style:GoogleFonts.cairo(color:Colors.white,fontSize:25,fontWeight:FontWeight.bold)),const Spacer(),IconButton(onPressed:()=>setState(()=>dark=!dark),icon:Icon(dark?Icons.light_mode:Icons.dark_mode,color:Colors.white))]),const SizedBox(height:14),Text('السَّلَامُ عَلَيْكُمْ',style:GoogleFonts.amiri(color:const Color(0xFFE8D9B8),fontSize:25)),const SizedBox(height:4),Text('اجعل للقرآن وِردًا من يومك',style:GoogleFonts.cairo(color:Colors.white70,fontSize:14)),const SizedBox(height:22),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white.withOpacity(.10),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white24)),child:Row(children:[const Icon(Icons.bookmark_added_outlined,color:gold,size:30),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('تابع من حيث وصلت',style:TextStyle(color:Colors.white70,fontSize:12)),Text('صفحة $pageNo من 604',style:GoogleFonts.cairo(color:Colors.white,fontSize:19,fontWeight:FontWeight.bold))])),FilledButton(onPressed:()=>setState(()=>tab=0),style:FilledButton.styleFrom(backgroundColor:gold,foregroundColor:emerald),child:const Text('متابعة'))]))]))),
    SliverPadding(padding:const EdgeInsets.fromLTRB(18,22,18,8),sliver:SliverToBoxAdapter(child:Row(children:[Text('اقرأ واستمع',style:GoogleFonts.cairo(fontSize:20,fontWeight:FontWeight.bold,color:fg)),const Spacer(),Text('604 صفحة',style:TextStyle(color:fg.withOpacity(.55)))]))),
    SliverPadding(padding:const EdgeInsets.symmetric(horizontal:18),sliver:SliverToBoxAdapter(child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:dark?const Color(0xFF20352E):Colors.white,borderRadius:BorderRadius.circular(22),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.04),blurRadius:16)]),child:Column(children:[Row(children:[Expanded(child:Text('طريقة العرض',style:GoogleFonts.cairo(color:fg,fontWeight:FontWeight.w700))),ChoiceChip(label:const Text('صفحات'),selected:pageMode,onSelected:(_)=>setState(()=>pageMode=true)),const SizedBox(width:6),ChoiceChip(label:const Text('آيات'),selected:!pageMode,onSelected:(_)=>setState(()=>pageMode=false))]),const Divider(height:24),if(loading)const Padding(padding:EdgeInsets.all(32),child:CircularProgressIndicator(color:emerald)) else if(pageData!=null) pageMode?_pageView(fg):_ayahView(fg),const SizedBox(height:14),Row(children:[IconButton(onPressed:()=>loadPage(pageNo-1),icon:const Icon(Icons.chevron_right)),Expanded(child:Center(child:Text('صفحة $pageNo',style:TextStyle(color:fg,fontWeight:FontWeight.bold)))),IconButton(onPressed:()=>loadPage(pageNo+1),icon:const Icon(Icons.chevron_left))]),const Divider(),Row(children:[DropdownButton<String>(value:reciters.any((e)=>e['identifier']==reciter)?reciter:null,items:reciters.map((e)=>DropdownMenuItem<String>(value:e['identifier'],child:SizedBox(width:170,child:Text(e['name']??e['identifier'],overflow:TextOverflow.ellipsis)))).toList(),onChanged:(v){if(v!=null){setState((){reciter=v;reciterName=reciters.firstWhere((e)=>e['identifier']==v)['name'];queuedPage=null;queuedReciter=null;});audioHandler.stop();}}),const Spacer(),FilledButton.icon(onPressed:playCurrent,icon:Icon(playing?Icons.pause:Icons.play_arrow),label:Text(playing?'إيقاف مؤقت':'استمع للصفحة'),style:FilledButton.styleFrom(backgroundColor:emerald,foregroundColor:Colors.white))])])))),
    SliverPadding(padding:const EdgeInsets.fromLTRB(18,20,18,30),sliver:SliverToBoxAdapter(child:Text('قال رسول الله ﷺ: «خيركم من تعلم القرآن وعلمه»',textAlign:TextAlign.center,style:GoogleFonts.amiri(color:gold,fontSize:18))))]);
  Widget _pageView(Color fg){final ayahs=pageData!['ayahs'] as List; final first=ayahs.first; return Container(width:double.infinity,padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:const Color(0xFFFFFCF4),border:Border.all(color:gold.withOpacity(.45)),borderRadius:BorderRadius.circular(12)),child:Column(children:[Text(first['surah']['name']??'',style:GoogleFonts.amiri(color:emerald,fontSize:21,fontWeight:FontWeight.bold)),const SizedBox(height:12),Text(ayahs.map((a)=>'${a['text']} ۞').join('  '),textAlign:TextAlign.center,textDirection:TextDirection.rtl,style:GoogleFonts.amiri(color:const Color(0xFF26352F),fontSize:25,height:2.0)),
    if(translationAyahs.isNotEmpty)...[const Divider(height:28,color:gold),...ayahs.map((a)=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:Text(translationFor(a),textAlign:TextAlign.center,textDirection:TextDirection.ltr,style:GoogleFonts.cairo(color:const Color(0xFF53645B),fontSize:14,height:1.7))))],
    const SizedBox(height:10),Text('﴿ $pageNo ﴾',style:const TextStyle(color:gold))]));}
  Widget _ayahView(Color fg){final ayahs=pageData!['ayahs'] as List;return Column(children:ayahs.map((a)=>Container(padding:const EdgeInsets.symmetric(vertical:12),decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Color(0x228C8068)))),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text(a['text'],textDirection:TextDirection.rtl,textAlign:TextAlign.right,style:GoogleFonts.amiri(fontSize:24,color:fg,height:1.8)),if(translationFor(a).isNotEmpty)Padding(padding:const EdgeInsets.only(top:5),child:Text(translationFor(a),textDirection:TextDirection.ltr,textAlign:TextAlign.left,style:GoogleFonts.cairo(fontSize:13,color:fg.withOpacity(.72),height:1.6)))])),IconButton(tooltip:'استمع للآية',onPressed:()=>_playAyah(a['number']),icon:const Icon(Icons.play_circle_outline,color:gold))])).toList());}
  Future<void> _playAyah(int n)async{try{final ayahs=(pageData?['ayahs'] as List? ?? []);final match=ayahs.cast<dynamic>().where((a)=>a['number']==n).toList();final surahName=match.isNotEmpty?match.first['surah']?['name']?.toString()??'القرآن الكريم':'القرآن الكريم';await audioHandler.playSingleAyah(globalAyahNumber:n,surahName:surahName,reciterId:reciter,reciterName:reciterName);queuedPage=null;queuedReciter=null;}catch(_){_snack('تعذر تشغيل الآية');}}
  Widget _surahTab(Color bg,Color fg)=>Column(children:[Container(color:emerald,padding:const EdgeInsets.all(20),child:Row(children:[Text('فهرس السور',style:GoogleFonts.cairo(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),const Spacer(),Text('${surahs.length} سورة',style:const TextStyle(color:Colors.white70))])),Expanded(child:surahs.isEmpty?const Center(child:CircularProgressIndicator()):ListView.separated(itemCount:surahs.length,separatorBuilder:(_,__)=>const Divider(height:1,indent:18,endIndent:18),itemBuilder:(c,i){final s=surahs[i];return ListTile(onTap:()async{final n=s['number'] as int; await _openSurah(n);},leading:CircleAvatar(backgroundColor:emerald.withOpacity(.1),child:Text('${s['number']}',style:const TextStyle(color:emerald))),title:Text(s['name'],style:GoogleFonts.amiri(fontSize:20,color:fg)),subtitle:Text('${s['englishName']} • ${s['numberOfAyahs']} آية',style:TextStyle(color:fg.withOpacity(.6))),trailing:const Icon(Icons.chevron_left));}))]);
  Future<void> _openSurah(int n) async { try { final r=await http.get(Uri.parse('$api/surah/$n/quran-uthmani')); if(r.statusCode!=200) throw Exception(); final data=jsonDecode(r.body)['data']; final firstPage=data['ayahs'][0]['page'] as int; await loadPage(firstPage); if(mounted)setState(()=>tab=0); } catch(_){_snack('تعذر فتح السورة');} }
  Widget _settings(Color bg,Color fg)=>ListView(padding:const EdgeInsets.all(20),children:[Text('الإعدادات',style:GoogleFonts.cairo(fontSize:24,fontWeight:FontWeight.bold,color:fg)),const SizedBox(height:20),SwitchListTile(value:dark,onChanged:(v)=>setState(()=>dark=v),title:Text('الوضع الليلي',style:TextStyle(color:fg))),ListTile(title:Text('القراء المتاحون',style:TextStyle(color:fg)),subtitle:Text('${reciters.length} قراء من مكتبة التلاوات',style:TextStyle(color:fg.withOpacity(.6)))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('ترجمة معاني القرآن',style:GoogleFonts.cairo(color:fg,fontWeight:FontWeight.bold)),const SizedBox(height:8),DropdownButtonFormField<String>(value:translationEdition,decoration:const InputDecoration(border:OutlineInputBorder(),contentPadding:EdgeInsets.symmetric(horizontal:12,vertical:8)),items:const [DropdownMenuItem(value:'en.sahih',child:Text('English – Sahih International')),DropdownMenuItem(value:'fr.hamidullah',child:Text('Français – Hamidullah')),DropdownMenuItem(value:'es.cortes',child:Text('Español – Cortes')),DropdownMenuItem(value:'ur.jalandhry',child:Text('اردو – جالندھری')),DropdownMenuItem(value:'id.indonesian',child:Text('Bahasa Indonesia')),DropdownMenuItem(value:'tr.diyanet',child:Text('Türkçe – Diyanet')),DropdownMenuItem(value:'de.bubenheim',child:Text('Deutsch – Bubenheim'))],onChanged:(v){if(v!=null)changeTranslation(v);}),const SizedBox(height:4),Text('تُعرض ترجمة المعاني أسفل الآيات، ويمكن تغيير اللغة في أي وقت.',style:TextStyle(color:fg.withOpacity(.6),fontSize:12))])),
    ListTile(title:Text('مصدر نص القرآن والتلاوات',style:TextStyle(color:fg)),subtitle:const Text('AlQuran Cloud API / Islamic Network CDN')),const Divider(),Text('وِرد | WIRD',textAlign:TextAlign.center,style:GoogleFonts.cairo(color:gold,fontSize:20,fontWeight:FontWeight.bold)),const Text('تطبيق مجاني بلا إعلانات',textAlign:TextAlign.center)]);
}
