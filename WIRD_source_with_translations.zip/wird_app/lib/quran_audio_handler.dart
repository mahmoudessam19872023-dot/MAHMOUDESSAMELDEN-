import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:just_audio/just_audio.dart';

/// Background audio handler for Quran recitation.
/// Publishes media metadata and playback controls to Android's media session.
class QuranAudioHandler extends BaseAudioHandler with QueueHandler, SeekHandler {
  final AudioPlayer _player = AudioPlayer();
  String? _activeQueueKey;
  StreamSubscription<PlaybackEvent>? _eventSubscription;
  StreamSubscription<int?>? _indexSubscription;

  QuranAudioHandler() {
    _eventSubscription = _player.playbackEventStream.listen(_broadcastState);
    _indexSubscription = _player.currentIndexStream.listen((index) {
      final items = queue.value;
      if (index != null && index >= 0 && index < items.length) {
        mediaItem.add(items[index]);
      }
    });
  }

  bool get isPlaying => _player.playing;
  Stream<bool> get playingStream => _player.playerStateStream.map((s) => s.playing).distinct();
  String? get activeQueueKey => _activeQueueKey;

  Future<void> playPage({
    required List<dynamic> ayahs,
    required String reciterId,
    required String reciterName,
    required int pageNumber,
  }) async {
    if (ayahs.isEmpty) return;
    final key = 'page:$pageNumber:$reciterId';
    final items = ayahs.map((ayah) {
      final number = ayah['number'] as int;
      final surahName = ayah['surah']?['name']?.toString() ?? 'القرآن الكريم';
      final ayahInSurah = ayah['numberInSurah']?.toString() ?? '';
      return MediaItem(
        id: 'https://cdn.islamic.network/quran/audio/128/$reciterId/$number.mp3',
        album: 'وِرد | القرآن الكريم',
        title: 'آية $ayahInSurah - $surahName',
        artist: reciterName,
        displayTitle: 'تلاوة القرآن الكريم',
          extras: {'globalAyahNumber': number, 'pageNumber': pageNumber},
      );
    }).toList();

    if (_activeQueueKey == key && _player.audioSource != null) {
      if (_player.processingState == ProcessingState.completed) {
        await _player.seek(Duration.zero, index: 0);
      }
      await _player.play();
      return;
    }

    final sources = items.map((item) => AudioSource.uri(Uri.parse(item.id), tag: item)).toList();
    _activeQueueKey = key;
    queue.add(items);
    mediaItem.add(items.first);
    await _player.setAudioSources(sources, initialIndex: 0, preload: true);
    await _player.play();
  }

  Future<void> playSingleAyah({
    required int globalAyahNumber,
    required String surahName,
    required String reciterId,
    required String reciterName,
  }) async {
    final item = MediaItem(
      id: 'https://cdn.islamic.network/quran/audio/128/$reciterId/$globalAyahNumber.mp3',
      album: 'وِرد | القرآن الكريم',
      title: 'استماع إلى آية من $surahName',
      artist: reciterName,
      displayTitle: 'تلاوة القرآن الكريم',
      extras: {'globalAyahNumber': globalAyahNumber},
    );
    _activeQueueKey = null;
    queue.add([item]);
    mediaItem.add(item);
    await _player.setAudioSource(AudioSource.uri(Uri.parse(item.id), tag: item));
    await _player.play();
  }

  void _broadcastState(PlaybackEvent event) {
    final playing = _player.playing;
    playbackState.add(PlaybackState(
      controls: [
        if (_player.hasPrevious) MediaControl.skipToPrevious,
        if (playing) MediaControl.pause else MediaControl.play,
        if (_player.hasNext) MediaControl.skipToNext,
        MediaControl.stop,
      ],
      systemActions: const {MediaAction.seek},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: _mapProcessingState(_player.processingState),
      playing: playing,
      updatePosition: _player.position,
      bufferedPosition: _player.bufferedPosition,
      speed: _player.speed,
      queueIndex: event.currentIndex,
    ));
  }

  AudioProcessingState _mapProcessingState(ProcessingState state) {
    switch (state) {
      case ProcessingState.idle:
        return AudioProcessingState.idle;
      case ProcessingState.loading:
        return AudioProcessingState.loading;
      case ProcessingState.buffering:
        return AudioProcessingState.buffering;
      case ProcessingState.ready:
        return AudioProcessingState.ready;
      case ProcessingState.completed:
        return AudioProcessingState.completed;
    }
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> skipToNext() async {
    if (_player.hasNext) await _player.seekToNext();
  }

  @override
  Future<void> skipToPrevious() async {
    if (_player.hasPrevious) await _player.seekToPrevious();
  }

  @override
  Future<void> skipToQueueItem(int index) async {
    if (index >= 0 && index < queue.value.length) await _player.seek(Duration.zero, index: index);
  }

  @override
  Future<void> stop() async {
    await _player.stop();
    _activeQueueKey = null;
    await super.stop();
  }

  Future<void> dispose() async {
    await _eventSubscription?.cancel();
    await _indexSubscription?.cancel();
    await _player.dispose();
  }
}
