# وِرد | WIRD — Flutter Android starter

An ad-free Arabic Quran reader prototype with page/ayah presentation toggle, page navigation, surah index, reciter selection, verse audio, and page playlist playback.

## Current implementation status

This is a **source project / MVP starter**, not a verified release build. The current execution environment does not have Flutter or Android SDK installed, so an APK/AAB could not be compiled or tested here. The Android folder contains the audio-service manifest declarations; generate the remaining platform scaffolding with `flutter create .` from this directory using Flutter stable.

## Build locally

1. Install Flutter stable and Android Studio (Android SDK + command-line tools).
2. Extract this project, open a terminal in `wird_app`.
3. Run:
   ```bash
   flutter create . --platforms=android
   flutter pub get
   flutter analyze
   flutter run
   ```
4. Before release, test on multiple Android versions/devices, verify every audio edition, test playback with screen locked, and run `flutter build appbundle --release`.

## Content and connectivity

- Arabic Uthmani text and page metadata: `https://api.alquran.cloud/v1/page/{page}/quran-uthmani`
- Surah metadata/text: AlQuran Cloud API.
- Audio verse streams: `https://cdn.islamic.network/quran/audio/128/{edition}/{globalAyahNumber}.mp3`
- API/CDN are third-party services. The app currently streams content and needs an internet connection; it does **not** yet provide full offline downloads/caching.
- Confirm provider terms, attribution requirements, reciter audio distribution permissions, and service availability before publishing. Do not imply endorsement by any reciter or provider.

## Release blockers before Google Play

- Add the full generated Android Gradle project and launcher icon assets.
- Implement and test true page-to-surah mapping / bookmark persistence beyond last page, repeat-ayah and repeat-range controls, robust player queue state, offline storage, search, and accessibility.
- Validate Quran text against an approved Mushaf source and obtain qualified review; never publish unverified sacred text.
- Create a public privacy policy URL (even if no personal data is collected), complete Play Data safety, content rating, target API requirements, app access declarations, store listing, screenshots, and signed AAB.
- Choose a unique Android application ID and protect the upload key. Current project uses Flutter's generated placeholder until configured.

## No ads

No advertising SDK, ad network, or advertising permission is included. Keep it that way in future dependencies and Play declarations.


## Background playback (implemented in source)

- Uses `audio_service` with a `just_audio` player owned by a background audio handler.
- Publishes Quran ayah metadata to Android's media session and notification.
- Exposes play, pause, stop, previous/next (when available), and seek controls.
- Declares the Android media-playback foreground service, media-button receiver, wake lock, and Android 13+ notification permission.
- The page playlist is kept in the background handler so playback can continue when the Flutter screen is no longer visible.

### Required device verification

This feature has been implemented in source but has **not** been compiled or device-tested in this environment (Flutter/Android SDK are unavailable). Before release, verify on Android 13, 14, and a current Android version: start a page, lock the screen, confirm audio continues, use notification/lock-screen play-pause and skip controls, test Bluetooth headset buttons, incoming-call audio focus, and battery saver. Also confirm notification permission behavior and that stopping playback removes the foreground notification.

## Translations added in this revision

The UI includes translations of meanings for English, French, Spanish, Urdu, Indonesian, Turkish, and German, selectable in Settings and displayed below the Arabic ayat. Arabic remains primary. These are fetched online from AlQuran Cloud; verify edition availability, licensing, and scholarly accuracy before public release.
